import React, { createContext, useState, useEffect, useContext } from 'react';
import { AuthContext } from './AuthProvider'; // import your existing AuthContext
import api from '../services/api';

export const AppDataContext = createContext();

export const AppDataProvider = ({ children }) => {
  const { loggedIn } = useContext(AuthContext); // use AuthContext to check login
  const [menuOptions, setMenuOptions] = useState([]);
  const [userSettings, setUserSettings] = useState(null);
  const [notifications, setNotifications] = useState([]);

  const [loading, setLoading] = useState(true); // optional: to track if data is ready
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchAppData() {
      setLoading(true);
      try {
        // Base data — available to everyone
        const menuRes = await api.get('/weekends');
        const menuData = await menuRes;
        setMenuOptions(menuData);
        // useEffect(() => {
        // }, [setMenuOptions, menuData])

        // Conditional API call — only if logged in
        if (loggedIn) {
          const [settingsRes, notificationsRes] = await Promise.all([
            api.get('/api/user-settings'),
            api.get('/api/notifications'),
          ]);

          const settingsData = await settingsRes.json();
          const notificationsData = await notificationsRes.json();

          setUserSettings(settingsData);
          setNotifications(notificationsData);
        }

        setError(null);
      } catch (err) {
        console.error('Failed to fetch app data:', err);
        setError(err);
        const weekendOptions = [
          {
            label: "פרשת בלק",
            checkin_val: "2025-07-11",
            checkout_val: "2025-07-13",
          },
          {
            label: "פרשת פינחס",
            checkin_val: "2025-07-18",
            checkout_val: "2025-07-20",
          },
          {
            label: "פרשת מטות-מסעי",
            checkin_val: "2025-07-25",
            checkout_val: "2025-07-27",
          },
          {
            label: "פרשת דברים",
            checkin_val: "2025-08-01",
            checkout_val: "2025-08-03",
          },
          {
            label: "פרשת ואתחנן",
            checkin_val: "2025-08-08",
            checkout_val: "2025-08-10",
          },
          {
            label: "פרשת עקב",
            checkin_val: "2025-08-15",
            checkout_val: "2025-08-17",
          },
          {
            label: "פרשת ראה",
            checkin_val: "2025-08-22",
            checkout_val: "2025-08-24",
          },
          {
            label: "פרשת שופטים",
            checkin_val: "2025-08-29",
            checkout_val: "2025-08-31",
          },
          {
            label: "פרשת כי־תצא",
            checkin_val: "2025-09-05",
            checkout_val: "2025-09-07",
          },
          {
            label: "פרשת כי־תבוא",
            checkin_val: "2025-09-12",
            checkout_val: "2025-09-14",
          },
        ];

        setMenuOptions(weekendOptions);
      } finally {
        setLoading(false);
      }
    }

    fetchAppData();
  }, [loggedIn]); // refetch when login state changes

  return (
    <AppDataContext.Provider
      value={{
        menuOptions,
        userSettings,
        notifications,
        loading,
        error,
      }}
    >
      {children}
    </AppDataContext.Provider>
  );
};

export const useAppData = () => {
  const context = useContext(AppDataContext);
  if (!context) {
    throw new Error('useAppData must be used within an AppDataProvider');
  }
  return context;
};
