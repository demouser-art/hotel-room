import React, { useState, useEffect, createContext } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api'; // central axios instance

export const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const navigate = useNavigate();

  const [loggedIn, setLoggedIn] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // for initial auth check

  // 🔐 Check token & fetch user on initial load
  useEffect(() => {
    const token = localStorage.getItem('authToken');
    if (token) {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      api.get('/auth/me')
        .then((res) => {
          setUser(res.data);
          setLoggedIn(true);
        })
        .catch(() => {
          logOut(); // invalid or expired token
        })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  // 🔑 Sign In
  const signIn = async (credentials) => {
    try {
      const res = await api.post('/auth/login', credentials);
      const { token, user } = res.data;

      localStorage.setItem('authToken', token);
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      setUser(user);
      setLoggedIn(true);
      navigate('/', { replace: true });
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  };

  // 🆕 Sign Up
  const signUp = async (formData) => {
    try {
      const res = await api.post('/auth/register', formData);
      const { token, user } = res.data;

      localStorage.setItem('authToken', token);
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      setUser(user);
      setLoggedIn(true);
      navigate('/', { replace: true });
    } catch (error) {
      console.error('Signup failed:', error);
      throw error;
    }
  };

  // 🚪 Logout
  const logOut = () => {
    localStorage.removeItem('authToken');
    delete api.defaults.headers.common['Authorization'];
    setUser(null);
    setLoggedIn(false);
    navigate('/login');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loggedIn,
        loading,
        signIn,
        signUp,
        logOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
