import TopHotelsGrid from './TopHotelsGrid';
import LuxaryHotelsGrid from './LuxaryHotelsGrid';
export { TopHotelsGrid, LuxaryHotelsGrid };
