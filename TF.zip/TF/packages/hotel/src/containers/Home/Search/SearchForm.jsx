import React, { useContext, useState } from 'react';
import { useNavigate, createSearchParams } from 'react-router-dom';
import isEmpty from 'lodash/isEmpty';
import { FaMapMarkerAlt, FaRegCalendar, FaUserFriends } from 'react-icons/fa';
import { Button, Popover, Tabs } from 'antd';
import DateRangePickerBox from 'components/UI/DatePicker/ReactDates';
import MapAutoComplete from 'components/Map/MapAutoComplete';
import { mapDataHelper } from 'components/Map/mapDataHelper';
import ViewWithPopup from 'components/UI/ViewWithPopup/ViewWithPopup';
import InputIncDec from 'components/UI/InputIncDec/InputIncDec';
import { setStateToUrl } from 'library/helpers/url_handler';
import { LISTING_POSTS_PAGE } from 'settings/constant';
import {
	FormWrapper,
	ComponentWrapper,
	RoomGuestWrapper,
	ItemWrapper,
	BookingDateWrapper,
	WeekendList
} from './Search.style';
import { AppDataContext } from '../../../context/AppDataProvider';
import TabPane from 'antd/es/tabs/TabPane';
import CalendarTabsDropdown from '../../../components/CalendarTabsDropdown/CalendarTabsDropdown';
import moment from 'moment';

const calendarItem = {
	separator: '-',
	format: 'MM-DD-YYYY',
	locale: 'en',
};

export default function SearchForm() {
	let navigate = useNavigate();
	const [searchDate, setSearchDate] = useState({
		setStartDate: null,
		setEndDate: null,
	});

	// place data
	const [mapValue, setMapValue] = useState([]);
	const updateValueFunc = (event) => {
		const { searchedPlaceAPIData } = event;
		if (!isEmpty(searchedPlaceAPIData)) {
			setMapValue(searchedPlaceAPIData);
		}
	};

	const guestTypes = [
		{ key: 'adults', label: 'Adults', min: 1 },
		{ key: 'children', label: 'Children', min: 0 },
		{ key: 'infants', label: 'Infants', min: 0 },
		{ key: 'rooms', label: 'Rooms', min: 1 },
		{ key: 'beds', label: 'Beds', min: 1 },
	];


	// Room guest state
	const [guestCounts, setGuestCounts] = useState({
		adults: 1,
		children: 0,
		infants: 0,
		rooms: 1,
		beds: 1,
	});

	const [activeTab, setActiveTab] = useState('dates');
	const { menuOptions } = useContext(AppDataContext);
	const [selectedWeekend, setSelectedWeekend] = useState(null);


	const handleWeekendSelect = (item) => {
		setSelectedWeekend(item);
		setSearchDate({
			setStartDate: moment.unix(item.checkin_val),
			setEndDate: moment.unix(item.checkout_val),
		});
	};

	const formatDateDisplay = () => {
		if (searchDate.setStartDate && searchDate.setEndDate) {
			// Both dates are selected, format them
			const start = moment(searchDate.setStartDate).format('MMM Do');
			const end = moment(searchDate.setEndDate).format('MMM Do');
			return `${start} - ${end}`;
		}
		// No dates selected, show placeholder
		return 'Start Date - End Date';
	};

	const handleIncrement = (type) => {
		setRoomGuest({
			...roomGuest,
			[type]: roomGuest[type] + 1,
		});
	};
	const handleDecrement = (type) => {
		if (roomGuest[type] <= 1) {
			return false;
		}
		setRoomGuest({
			...roomGuest,
			[type]: roomGuest[type] - 1,
		});
	};
	const handleIncDecOnChange = (e, type) => {
		let currentValue = e.target.value;
		setRoomGuest({
			...roomGuest,
			[type]: currentValue,
		});
	};

	// navigate to the search page
	const goToSearchPage = () => {
		let tempLocation = [];
		const mapData = mapValue ? mapDataHelper(mapValue) : [];
		mapData &&
			mapData.map((singleMapData, i) => {
				return tempLocation.push({
					formattedAddress: singleMapData ? singleMapData.formattedAddress : '',
					lat: singleMapData ? singleMapData.lat.toFixed(3) : null,
					lng: singleMapData ? singleMapData.lng.toFixed(3) : null,
				});
			});
		const location = tempLocation ? tempLocation[0] : {};
		const query = {
			date_range: searchDate,
			...guestCounts, // includes adults, children, infants, rooms, beds
			location,
		};

		const search = setStateToUrl(query);
		navigate({
			pathname: LISTING_POSTS_PAGE,
			search: `?${createSearchParams(search)}`,
		});
	};

	const onChange = (key) => {
		console.log(key);
	};

	const calendarItems = [
		{
			key: '1',
			label: 'Calendar',
			child: <DateRangePickerBox
				item={calendarItem}
				startDateId="startDateId-id-home"
				endDateId="endDateId-id-home"
				updateSearchData={(setDateValue) => setSearchDate(setDateValue)}
				showClearDates={true}
				small={true}
				numberOfMonths={2}
			/>
		}
	]
	return (
		<FormWrapper>
			<ComponentWrapper>
				<FaMapMarkerAlt className="map-marker" />
				<MapAutoComplete updateValue={(value) => updateValueFunc(value)} />
				<svg
					xmlns="http://www.w3.org/2000/svg"
					version="1.1"
					x="0px"
					y="0px"
					width="30"
					height="30"
					viewBox="0 0 144.083 144"
					enableBackground="new 0 0 144.083 144"
					className="target"
				>
					<path d="M117.292,69h-13.587C102.28,53.851,90.19,41.761,75.042,40.337V26.5h-6v13.837C53.893,41.761,41.802,53.851,40.378,69  H26.792v6h13.587c1.425,15.148,13.515,27.238,28.663,28.663V117.5h6v-13.837C90.19,102.238,102.28,90.148,103.705,75h13.587V69z   M72.042,97.809c-14.23,0-25.809-11.578-25.809-25.809c0-14.231,11.578-25.809,25.809-25.809S97.85,57.769,97.85,72  C97.85,86.23,86.272,97.809,72.042,97.809z" />
					<path d="M72.042,52.541c-10.729,0-19.459,8.729-19.459,19.459s8.729,19.459,19.459,19.459S91.5,82.729,91.5,72  S82.771,52.541,72.042,52.541z M72.042,85.459c-7.421,0-13.459-6.037-13.459-13.459c0-7.421,6.038-13.459,13.459-13.459  S85.5,64.579,85.5,72C85.5,79.422,79.462,85.459,72.042,85.459z" />
				</svg>
			</ComponentWrapper>

			<ComponentWrapper>
				{/* <DateRangePickerBox
					item={calendarItem}
					startDateId="startDateId-id-home"
					endDateId="endDateId-id-home"
					updateSearchData={(setDateValue) => setSearchDate(setDateValue)}
					showClearDates={true}
					small={true}
					numberOfMonths={2}
					/> */}
				{/* <FaRegCalendar className="calendar" />
				<BookingDateWrapper>
					<ViewWithPopup
						view={<span></span>}
						popup={
							<CalendarTabsDropdown
								weekendOptions={menuOptions}
								onDateChange={(range) => setSearchDate(range)}
							/>
						}
					/>
				</BookingDateWrapper> */}
				<Popover
					content={
						<CalendarTabsDropdown
							setSearchDate={setSearchDate}
							weekendOptions={menuOptions}
							onDateChange={(range) => setSearchDate(range)}
						/>
					}
					trigger="click"
					placement="bottom"
					overlayInnerStyle={{ width: '640px' }}
				>
					<div className="calendar-input-trigger" style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}>
						<FaRegCalendar />
						<span>{formatDateDisplay()}</span>
					</div>
				</Popover>
			</ComponentWrapper>

			<ComponentWrapper>
				<FaUserFriends className="user-friends" />
				<ViewWithPopup
					key={200}
					noView={true}
					className="room_guest"
					view={
						<Button type="default">
							{guestTypes.map(({ key, label }) => (
								<span key={key} style={{ margin: '0 3px' }}>
									{guestCounts[key] > 0 && `${label}: ${guestCounts[key]}`}
								</span>
							))}
						</Button>
					}
					popup={
						<RoomGuestWrapper>
							{guestTypes.map(({ key, label, min }) => (
								<ItemWrapper key={key}>
									<strong>{label}</strong>
									<InputIncDec
										id={key}
										increment={() =>
											setGuestCounts({ ...guestCounts, [key]: guestCounts[key] + 1 })
										}
										decrement={() =>
											guestCounts[key] > min &&
											setGuestCounts({ ...guestCounts, [key]: guestCounts[key] - 1 })
										}
										onChange={(e) => {
											const val = parseInt(e.target.value, 10) || min;
											setGuestCounts({ ...guestCounts, [key]: Math.max(val, min) });
										}}
										value={guestCounts[key]}
									/>
								</ItemWrapper>
							))}
						</RoomGuestWrapper>
					}
				/>

			</ComponentWrapper>

			<Button
				type="primary"
				htmlType="submit"
				size="large"
				onClick={goToSearchPage}
			>
				Find Hotels
			</Button>
		</FormWrapper>
	);
}
