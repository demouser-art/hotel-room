import React from 'react';
import styled from 'styled-components';
import { useForm, Controller } from 'react-hook-form';
import { style } from 'styled-system';
// import ReCAPTCHA from 'react-google-recaptcha';

const Container = styled.div`
  padding: 2rem 1rem; /* default padding for small screens */
  background: #f9f9f9;
  
  @media (min-width: 768px) {
    padding: 3rem 2rem;
  }
  
  @media (min-width: 1024px) {
    padding: 4rem 3rem;
  }
  
  @media (min-width: 1280px) {
    padding: 5rem 5rem;
    padding-top: 100px;
    padding-bottom: 250px;
  }
`;

const ContactUsRow = styled.div`
    display: flex;
  flex-wrap: wrap;
  max-width: 1200px;
  margin: 0 auto;
`

const LeftCol = styled.div`
  flex: 1 1 40%;
  padding-right: 2rem;
`;

const RightCol = styled.div`
  flex: 1 1 60%;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const Heading = styled.h2`
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 1rem;
`;

const Text = styled.p`
  font-size: 1rem;
  margin-bottom: 1.5rem;
`;

const InfoItem = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 1rem;
  color: #999;
`;

const FormGroup = styled.div`
  display: flex;
  gap: 1rem;
  > div {
    flex: 1;
  }
`;

const FieldWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;

const Input = styled.input`
  padding: 14px 18px;
  border-radius: 10px;
  border: none;
  background: #fff;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.03);
  font-size: 0.95rem;
  color: #333;
  &::placeholder {
    color: #999;
    font-weight: 500;
  }
`;

const TextArea = styled.textarea`
  padding: 14px 18px;
  border-radius: 10px;
  border: none;
  background: #fff;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.03);
  font-size: 0.95rem;
  resize: none;
  color: #333;
  height: 120px;
  &::placeholder {
    color: #999;
    font-weight: 500;
  }
`;

const ErrorText = styled.span`
  color: #e74c3c;
  font-size: 0.85rem;
  margin-top: 0.25rem;
`;

const SubmitRow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  margin-top: 1rem;
`;

const SubmitButton = styled.button`
  background: #f46a5f;
  color: white;
  padding: 0.85rem 2.5rem;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  margin-top: 1rem;
`;

const RecaptchaWrapper = styled.div`
  margin-top: 1rem;
  @media (max-width: 768px) {
    width: 100%;
    margin-top: 1.5rem;
  }
`;


export default function ContactForm() {
  const {
    handleSubmit,
    control,
    setValue,
    getValues,
    formState: { errors },
  } = useForm();

  const [captchaToken, setCaptchaToken] = React.useState(null);

  const onSubmit = (data) => {
    // if (!captchaToken) {
    //   alert('Please complete the reCAPTCHA');
    //   return;
    // }

    console.log('Form Submitted', { ...data, captchaToken });
    // Do something with data
  };

  return (
    <Container>
      <ContactUsRow>
        <LeftCol>
          <Heading>Get in Touch</Heading>
          <Text>
            Connect with one of our vacation advisors for any questions you may have
          </Text>
          <InfoItem>📞 845.999.8452</InfoItem>
          <InfoItem>✉️ reservations@guestay.com</InfoItem>
          <InfoItem>📍 3 Tarnopol Way. Suite 402, Monroe, New York 10950</InfoItem>
        </LeftCol>

        <RightCol as="form" onSubmit={handleSubmit(onSubmit)}>
          <FormGroup>
            <FieldWrapper>
              <Controller
                name="firstName"
                control={control}
                rules={{ required: true }}
                render={({ field }) => <Input placeholder="First Name" {...field} />}
              />
              {errors.firstName && <ErrorText>Please enter first name</ErrorText>}
            </FieldWrapper>
            <FieldWrapper>
              <Controller
                name="lastName"
                control={control}
                rules={{ required: true }}
                render={({ field }) => <Input placeholder="Last Name" {...field} />}
              />
              {errors.lastName && <ErrorText>Please enter last name</ErrorText>}
            </FieldWrapper>
          </FormGroup>

          <FormGroup>
            <FieldWrapper>
              <Controller
                name="email"
                control={control}
                rules={{
                  required: true,
                  pattern: /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
                }}
                render={({ field }) => <Input placeholder="Email" type="email" {...field} />}
              />
              {errors.email?.type === 'required' && (
                <ErrorText>Please enter email id</ErrorText>
              )}
              {errors.email?.type === 'pattern' && (
                <ErrorText>Please enter valid email id</ErrorText>
              )}
            </FieldWrapper>

            <FieldWrapper>
              <Controller
                name="phone"
                control={control}
                rules={{ required: true }}
                render={({ field }) => <Input placeholder="Phone" {...field} />}
              />
              {errors.phone && <ErrorText>Please enter phone number</ErrorText>}
            </FieldWrapper>
          </FormGroup>

          <FieldWrapper>
            <Controller
              name="message"
              control={control}
              rules={{ required: true }}
              render={({ field }) => <TextArea placeholder="Message" {...field} />}
            />
            {errors.message && <ErrorText>Please enter message</ErrorText>}
          </FieldWrapper>

          <SubmitRow>
            <SubmitButton type="submit">Submit</SubmitButton>
            {/* <RecaptchaWrapper>
            <ReCAPTCHA
              sitekey="YOUR_RECAPTCHA_SITE_KEY"
              onChange={(token) => setCaptchaToken(token)}
            />
            {!captchaToken && <ErrorText>Please complete the reCAPTCHA.</ErrorText>}
          </RecaptchaWrapper> */}
          </SubmitRow>
        </RightCol>
      </ContactUsRow>
    </Container>
  );
}
