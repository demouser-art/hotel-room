// import React, { useState } from 'react';
// import { InputNumber, Button, message } from 'antd';
// import {
//   UserOutlined,
//   HomeOutlined
// } from '@ant-design/icons';
// import { RoomSelectionWrapper, RoomCard, SelectedRoomsWrapper } from '../SinglePageView.style';

// const RoomSelection = ({ roomTypes, onRoomSelect, selectedRooms, onUpdateSelection }) => {
//   const [roomQuantities, setRoomQuantities] = useState({});

//   const handleRoomQuantityChange = (roomId, quantity) => {
//     setRoomQuantities(prev => ({
//       ...prev,
//       [roomId]: quantity
//     }));
//   };

//   const handleSelectRoom = (room) => {
//     const quantity = roomQuantities[room.id] || 1;

//     if (quantity > room.available) {
//       message.error(`Only ${room.available} rooms available`);
//       return;
//     }

//     const selectedRoom = {
//       ...room,
//       quantity,
//       price: parseFloat(room.price)
//     };

//     onRoomSelect(selectedRoom);
//     message.success(`${quantity} ${room.name}(s) added to selection`);
//   };

//   const clearSelection = () => {
//     onUpdateSelection([]);
//     message.success('Selection cleared');
//   };

//   const removeRoom = (roomId) => {
//     const updatedRooms = selectedRooms.filter(room => room.id !== roomId);
//     onUpdateSelection(updatedRooms);
//     message.success('Room removed from selection');
//   };

//   return (
//     <RoomSelectionWrapper>
//       <div className="room-selection-header">
//         <h2>Choose Your Perfect Room</h2>
//         <p>Select your preferred room type for the best experience</p>
//       </div>

//       <div className="rooms-grid">
//         {roomTypes.map(room => (
//           <RoomCard key={room.id} available={room.available}>
//             <div className="room-image">
//               <img src={room.image.url} alt={room.name} />
//               <div className="availability-badge">
//                 {room.available > 0 ? `${room.available} available` : 'Sold out'}
//               </div>
//             </div>

//             <div className="room-content">
//               <div className="room-header">
//                 <div className="room-title-section">
//                   <h3>{room.name}</h3>
//                   <div className="room-info">
//                     <span><UserOutlined /> Up to {room.maxGuests} guests</span>
//                     <span><HomeOutlined /> {room.size}</span>
//                     <span>🛏️ {room.bedType}</span>
//                   </div>
//                   <div className="room-description">{room.description}</div>
//                 </div>

//                 <div className="room-price">
//                   <span className="current-price">${room.price}</span>
//                   {room.originalPrice && (
//                     <span className="original-price">${room.originalPrice}</span>
//                   )}
//                   <span className="per-night">per night</span>
//                 </div>
//               </div>

//               <div className="room-amenities">
//                 <div className="amenities-title">Room Amenities:</div>
//                 <div className="amenities-list">
//                   {room.amenities.slice(0, 4).map((amenity, index) => (
//                     <span key={index} className="amenity-tag">{amenity.amenityText}</span>
//                   ))}
//                   {room.amenities.length > 4 && (
//                     <span className="amenity-tag">+{room.amenities.length - 4} more</span>
//                   )}
//                 </div>
//               </div>

//               <div className="room-actions">
//                 <div className="quantity-selector">
//                   <label>Rooms:</label>
//                   <InputNumber
// 										type='number'
//                     min={1}
//                     max={room.available}
//                     value={roomQuantities[room.id] || 1}
//                     onChange={(value) => handleRoomQuantityChange(room.id, value)}
//                     disabled={room.available === 0}
//                   />
//                 </div>
//                 <Button
//                   type="primary"
//                   className="select-room-btn"
//                   onClick={() => handleSelectRoom(room)}
//                   disabled={room.available === 0}
//                 >
//                   {room.available === 0 ? 'Not Available' : 'Select Room'}
//                 </Button>
//               </div>
//             </div>
//           </RoomCard>
//         ))}
//       </div>

//       {selectedRooms.length > 0 && (
//         <SelectedRoomsWrapper>
//           <div className="selected-rooms-header">
//             <h3>Selected Rooms ({selectedRooms.length})</h3>
//             <button className="clear-selection" onClick={clearSelection}>
//               Clear All
//             </button>
//           </div>

//           <div className="selected-rooms-list">
//             {selectedRooms.map((room, index) => (
//               <div key={`${room.id}-${index}`} className="selected-room-item">
//                 <div className="room-info">
//                   <div className="room-type">{room.name}</div>
//                   <div className="room-details">
//                     {room.quantity} room{room.quantity > 1 ? 's' : ''}
//                   </div>
//                 </div>
//                 <div className="room-total">
//                   <div className="quantity">
//                     ${room.price} × {room.quantity}
//                   </div>
//                   <div className="price">${room.price * room.quantity}</div>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </SelectedRoomsWrapper>
//       )}
//     </RoomSelectionWrapper>
//   );
// };

// export default RoomSelection;

import React, { useState } from 'react';
import { InputNumber, Button, message } from 'antd';
import {
  UserOutlined,
  HomeOutlined
} from '@ant-design/icons';
import { RoomSelectionWrapper, RoomCard, SelectedRoomsWrapper } from '../SinglePageView.style';

const RoomSelection = ({ roomTypes, onRoomSelect, selectedRooms, onUpdateSelection }) => {
  const [roomQuantities, setRoomQuantities] = useState({});

  const handleRoomQuantityChange = (roomId, quantity) => {
    setRoomQuantities(prev => ({
      ...prev,
      [roomId]: quantity
    }));
  };

  const handleSelectRoom = (room) => {
    const quantity = roomQuantities[room.id] || 1;

    if (quantity > room.available) {
      message.error(`Only ${room.available} rooms available`);
      return;
    }

    const selectedRoom = {
      ...room,
      quantity,
      price: parseFloat(room.price)
    };

    onRoomSelect(selectedRoom);
    message.success(`${quantity} ${room.name}(s) added to selection`);
  };

  const clearSelection = () => {
    onUpdateSelection([]);
    message.success('Selection cleared');
  };

  const removeRoom = (roomId) => {
    const updatedRooms = selectedRooms.filter(room => room.id !== roomId);
    onUpdateSelection(updatedRooms);
    message.success('Room removed from selection');
  };

  return (
    <RoomSelectionWrapper>
      <div className="room-selection-header">
        <h2>Choose Your Perfect Room</h2>
        <p>Select your preferred room type for the best experience</p>
      </div>

      <div className="rooms-grid">
        {roomTypes && roomTypes.length > 0 ? roomTypes.map(room => (
          <RoomCard key={room.id} available={room.available}>
            <div className="room-image">
              <img src={room.image.url} alt={room.name} />
              <div className="availability-badge">
                {room.available > 0 ? `${room.available} available` : 'Sold out'}
              </div>
            </div>

            <div className="room-content">
              <div className="room-header">
                <div className="room-title-section">
                  <h3>{room.name}</h3>
                  <div className="room-info">
                    <span><UserOutlined /> Up to {room.maxGuests} guests</span>
                    <span><HomeOutlined /> {room.size}</span>
                    <span>🛏️ {room.bedType}</span>
                  </div>
                  <div className="room-description">{room.description}</div>
                </div>

                <div className="room-price">
                  <span className="current-price">${room.price}</span>
                  {room.originalPrice && (
                    <span className="original-price">${room.originalPrice}</span>
                  )}
                  <span className="per-night">per night</span>
                </div>
              </div>

              <div className="room-amenities">
                <div className="amenities-title">Room Amenities:</div>
                <div className="amenities-list">
                  {room.amenities && room.amenities.length > 0 ? (
                    <>
                      {room.amenities.slice(0, 4).map((amenity, index) => (
                        <span key={index} className="amenity-tag">{amenity.amenityText}</span>
                      ))}
                      {room.amenities.length > 4 && (
                        <span className="amenity-tag">+{room.amenities.length - 4} more</span>
                      )}
                    </>
                  ) : (
                    <span className="amenity-tag">Standard amenities included</span>
                  )}
                </div>
              </div>

              <div className="room-actions">
                <div className="quantity-selector">
                  <label>Rooms:</label>
                  <InputNumber
										type='number'
                    min={1}
                    max={room.available}
                    value={roomQuantities[room.id] || 1}
                    onChange={(value) => handleRoomQuantityChange(room.id, value)}
                    disabled={room.available === 0}
                  />
                </div>
                <Button
                  type="primary"
                  className="select-room-btn"
                  onClick={() => handleSelectRoom(room)}
                  disabled={room.available === 0}
                >
                  {room.available === 0 ? 'Not Available' : 'Select Room'}
                </Button>
              </div>
            </div>
          </RoomCard>
        )) : (
          <div style={{textAlign: 'center', padding: '40px', color: '#666'}}>
            No rooms available
          </div>
        )}
      </div>

      {selectedRooms && selectedRooms.length > 0 && (
        <SelectedRoomsWrapper>
          <div className="selected-rooms-header">
            <h3>Selected Rooms ({selectedRooms.length})</h3>
            <button className="clear-selection" onClick={clearSelection}>
              Clear All
            </button>
          </div>

          <div className="selected-rooms-list">
            {selectedRooms.map((room, index) => (
              <div key={`${room.id}-${index}`} className="selected-room-item">
                <div className="room-info">
                  <div className="room-type">{room.name}</div>
                  <div className="room-details">
                    {room.quantity} room{room.quantity > 1 ? 's' : ''}
                  </div>
                </div>
                <div className="room-total">
                  <div className="quantity">
                    ${room.price} × {room.quantity}
                  </div>
                  <div className="price">${room.price * room.quantity}</div>
                </div>
              </div>
            ))}
          </div>
        </SelectedRoomsWrapper>
      )}
    </RoomSelectionWrapper>
  );
};

export default RoomSelection;
