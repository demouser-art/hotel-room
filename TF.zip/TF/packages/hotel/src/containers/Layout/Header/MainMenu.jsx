import React, { useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu } from 'antd';

import {
  HOME_PAGE,
  LISTING_POSTS_PAGE,
  CONTACT_US_PAGE
} from 'settings/constant';
import { AppDataContext, useAppData } from '../../../context/AppDataProvider';
import { format } from 'date-fns';
import styled from 'styled-components';


const MainMenu = ({ className, isLoggedIn }) => {
  // const { menuOptions, loading } = useAppData();
  const { menuOptions } = useContext(AppDataContext);
  const menuItems = [
    {
      label: <NavLink to={HOME_PAGE}>Explore Voyaju</NavLink>,
      key: 'menu-1'
    },
    ...(menuOptions && menuOptions?.data?.length > 0 ?
      [{
        label: 'Weekends',
        key: 'menu-2',
        children: (menuOptions?.data || []).map((item, index) => {
          const checkin = new Date(item.checkin_val * 1000);  // Convert Unix timestamp to Date
          const checkout = new Date(item.checkout_val * 1000);

          const formattedCheckin = format(checkin, 'MMM do');
          const formattedCheckout = format(checkout, 'MMM do');
          return {
            label: (

              <NavLink style={{ height: 'auto' }}
                to={`${LISTING_POSTS_PAGE}?weekend_id=${index}&checkin_filter=${encodeURIComponent(
                  item.label
                )}&selected_tab=weekends&checkin_val=${item.checkin_val}&checkout_val=${item.checkout_val}&ref=home`}
              >
                <WeekendMenuItem>
                  <span className='weekend-name'>{item.label}</span>
                  <span className='weekend-date'>
                    {formattedCheckin} / {formattedCheckout}
                  </span>
                </WeekendMenuItem>
              </NavLink>
            ),
            key: `menu-2-${index}`,
          };
        }),
      }] : []),
    {
      label: <NavLink to={LISTING_POSTS_PAGE}>Vacation Rentals</NavLink>,
      key: 'menu-3'
    },
    ...(
      !isLoggedIn
        ? [
          {
            label: <NavLink to={CONTACT_US_PAGE}>Contact Us</NavLink>,
            key: 'menu-4'
          },
        ]
        : []
    ),
  ];
  const getSelectedKey = () => {
    if (location.pathname === HOME_PAGE) return ['menu-1'];
    if (location.pathname === LISTING_POSTS_PAGE && location.search.includes('selected_tab=weekends')) return ['menu-2'];
    if (location.pathname === LISTING_POSTS_PAGE) return ['menu-3'];
    if (location.pathname === CONTACT_US_PAGE) return ['menu-4'];
    return [];
  };
  console.log({getSelectedKey:getSelectedKey()})

  return <Menu selectedKeys={getSelectedKey()} className={className + ' main-menu'} items={menuItems} />;
};

export default MainMenu;

export const WeekendMenuItem = styled.div`
  display: flex;
  flex-direction: column;
  gap: 3px;
  padding-top: 6px;
  padding-bottom: 6px;

  .weekend-name{
    line-height: 1.25;
  }

  .weekend-date{
    line-height: 1.25;
    font-size: 12px;
    opacity: 0.7;
  }
`;
