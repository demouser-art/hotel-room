import { useSearchParams } from 'react-router-dom';

const getFilterParams = () => {
  const [searchParams] = useSearchParams();

  const dateRange = searchParams.get('date_range')?.split(',');
  const checkIn = dateRange?.[0];
  const checkOut = dateRange?.[1];

  const adults = parseInt(searchParams.get('adults') || '1');
  const children = parseInt(searchParams.get('children') || '0');
  const infants = parseInt(searchParams.get('infants') || '0');
  const rooms = parseInt(searchParams.get('rooms') || '1');
  const beds = parseInt(searchParams.get('beds') || '1');

  return {
    checkIn,
    checkOut,
    guests: { adults, children, infants },
    rooms,
    beds
  };
};

export default getFilterParams;
