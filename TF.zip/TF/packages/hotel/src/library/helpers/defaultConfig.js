export const GOOGLE_MAP_LIBRARIES = ['places', 'drawing', 'geometry'];
