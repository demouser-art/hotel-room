// import React, { useState, useRef, useEffect } from 'react';
// import styled from 'styled-components';
// import { Tabs } from 'antd';
// import moment from 'moment';
// import { AppDataContext } from 'context/AppDataProvider';
// import DateRangePickerBox from 'components/UI/DatePicker/ReactDates';
// import { format } from 'date-fns';

// const { TabPane } = Tabs;

// const CalendarContainer = styled.div`
//   position: relative;
// `;

// const PopupWrapper = styled.div`
//   position: absolute;
//   top: 100%;
//   left: 0;
//   z-index: 1000;
//   background: white;
//   box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
//   border-radius: 12px;
//   padding: 20px;
//   width: 600px;
// `;

// export default function CalendarTabsDropdown({ searchDate, setSearchDate }) {
// 	const [isOpen, setIsOpen] = useState(true);
// 	const { menuOptions } = React.useContext(AppDataContext);
// 	const wrapperRef = useRef(null);

// 	const toggleOpen = () => setIsOpen((prev) => !prev);

// 	const closePopup = () => setIsOpen(false);

// 	// Handle outside click
// 	useEffect(() => {
// 		function handleClickOutside(event) {
// 			if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
// 				closePopup();
// 			}
// 		}
// 		document.addEventListener('mousedown', handleClickOutside);
// 		return () => document.removeEventListener('mousedown', handleClickOutside);
// 	}, []);

// 	return (
// 		<CalendarContainer ref={wrapperRef}>
// 			{/* Your Start/End Input Display */}
// 			{/* <div onClick={toggleOpen}>
// 				<DateRangePickerBox
// 					item={{}}
// 					startDateId="start-date-id"
// 					endDateId="end-date-id"
// 					showClearDates={true}
// 					small={true}
// 					numberOfMonths={2}
// 					isDisabled
// 				/>
// 			</div>

// 			{isOpen && (
// 			)} */}
// 			<PopupWrapper>
// 				<Tabs defaultActiveKey="dates">
// 					<TabPane tab="Dates" key="dates">
// 						<DateRangePickerBox
// 							item={{}}
// 							startDateId="startDateId-popup"
// 							endDateId="endDateId-popup"
// 							updateSearchData={(val) => {
// 								setSearchDate(val);
// 								closePopup();
// 							}}
// 							showClearDates={true}
// 							small={true}
// 							numberOfMonths={2}
// 						/>
// 					</TabPane>

// 					<TabPane tab="Weekends" key="weekends">
// 						<div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
// 							{(menuOptions?.data || []).map((item, idx) => {
// 								const checkin = new Date(item.checkin_val * 1000);  // Convert Unix timestamp to Date
// 								const checkout = new Date(item.checkout_val * 1000);

// 								const formattedCheckin = format(checkin, 'MMM do');
// 								const formattedCheckout = format(checkout, 'MMM do');
// 								return (
// 									<div
// 										key={idx}
// 										onClick={() => {
// 											setSearchDate({
// 												setStartDate: moment.unix(item.checkin_val),
// 												setEndDate: moment.unix(item.checkout_val),
// 											});
// 											closePopup();
// 										}}
// 										style={{
// 											padding: '10px',
// 											border: '1px solid #ddd',
// 											borderRadius: '8px',
// 											cursor: 'pointer',
// 										}}
// 									>
// 										<div>{item.label}</div>
// 										<div style={{ fontSize: 12, color: '#999' }}>
// 											{formattedCheckin} /{' '}
// 											{formattedCheckout}
// 										</div>
// 									</div>
// 								)
// 							})}
// 						</div>
// 					</TabPane>

// 					<TabPane tab="Flexible Days" key="flexible">
// 						Coming soon...
// 					</TabPane>
// 				</Tabs>
// 			</PopupWrapper>
// 		</CalendarContainer>
// 	);
// }


import React from 'react';
import styled from 'styled-components';
import { Tabs } from 'antd';
import moment from 'moment';
import { AppDataContext } from 'context/AppDataProvider';
import DateRangePickerBox from 'components/UI/DatePicker/ReactDates';
import { format } from 'date-fns';

const { TabPane } = Tabs;


export default function CalendarTabsDropdown({ setSearchDate }) {
  const { menuOptions } = React.useContext(AppDataContext);

  return (
    <div>
      <Tabs defaultActiveKey="dates">
        <TabPane tab="Dates" key="dates">
          <DateRangePickerBox
            updateSearchData={(val) => {
              setSearchDate(val);
            }}
            numberOfMonths={2}
          />
        </TabPane>

        <TabPane className='calendar-tab-container' tab="Weekends" key="weekends">
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {(menuOptions?.data || []).map((item, idx) => {
              const checkin = new Date(item.checkin_val * 1000);
              const checkout = new Date(item.checkout_val * 1000);
              const formattedCheckin = format(checkin, 'MMM do');
              const formattedCheckout = format(checkout, 'MMM do');
              return (
                <div
                  key={idx}
                  onClick={() => {
                    setSearchDate({
                      setStartDate: moment.unix(item.checkin_val),
                      setEndDate: moment.unix(item.checkout_val),
                    });
                  }}
                  style={{
                    padding: '10px',
                    border: '1px solid #ddd',
                    borderRadius: '8px',
                    cursor: 'pointer',
                  }}
                >
                  <div>{item.label}</div>
                  <div style={{ fontSize: 12, color: '#999' }}>
                    {formattedCheckin} / {formattedCheckout}
                  </div>
                </div>
              );
            })}
          </div>
        </TabPane>

        <TabPane tab="Flexible Days" key="flexible">
          Coming soon...
        </TabPane>
      </Tabs>
    </div>
  );
}

