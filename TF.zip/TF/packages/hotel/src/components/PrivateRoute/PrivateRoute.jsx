import { useContext } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { AuthContext } from '../context/AuthProvider';
import Loader from 'components/Loader/Loader';

const PrivateRoute = () => {
  const { loggedIn, loading } = useContext(AuthContext);

  if (loading) return <Loader />;

  return loggedIn ? <Outlet /> : <Navigate to="/login" replace />;
};

export default PrivateRoute;
