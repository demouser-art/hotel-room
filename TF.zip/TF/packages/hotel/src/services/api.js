// src/services/api.js
import axios from 'axios';

// Set your backend base URL
const API_BASE_URL = 'https://686f74a491e85fac42a12506.mockapi.io/api/';

// Create an Axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // Optional: 10s timeout for all requests
});

// 🔐 Attach auth token (if exists) to every request
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ⚠️ Global error handler (customize as needed)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      const { status } = error.response;

      // Auto logout if unauthorized
      if (status === 401) {
        localStorage.removeItem('authToken');
        window.location.href = '/login';
      }

      // Handle other common error codes here
      // Example: 500, 403, etc.
    }

    return Promise.reject(error);
  }
);

export default api;
