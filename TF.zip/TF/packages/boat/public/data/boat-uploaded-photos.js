export const uploadedPhotosData = [
    {
        id: 'uploaded-one',
        img: '/images/top-boats/boat-one.jpg',
    },
    {
        id: 'uploaded-two',
        img: '/images/top-boats/boat-two.jpg',
    },
    {
        id: 'uploaded-three',
        img: '/images/top-boats/boat-three.jpg',
    },
    {
        id: 'uploaded-four',
        img: '/images/top-boats/boat-four.jpg',
    },
]