export const chatData = [
    {
      id: '1',
      name: 'Brian Smith',
      image: 'https://randomuser.me/api/portraits/men/62.jpg',
      message: 'Nice to meet you!',
      isActive: true,
    },
    {
      id: '2',
      name: 'Miyah Myles',
      image:
        'https://randomuser.me/api/portraits/men/9.jpg',
      message: 'Thank you',
      isActive: false,
    },
    {
      id: '3',
      name: 'Sebastian Stan',
      image:
        'https://randomuser.me/api/portraits/men/41.jpg',
      message: 'Hi! Are you there?',
      isActive: true,
    },
    {
      id: '4',
      name: 'Andreas Brixen',
      image:
        'https://randomuser.me/api/portraits/men/86.jpg',
      message: 'You are welcome',
      isActive: false,
    },
    {
      id: '5',
      name: 'Davina Billings',
      image:
        'https://randomuser.me/api/portraits/women/91.jpg',
      message: 'Hi!',
      isActive: true,
    },
  ];
  