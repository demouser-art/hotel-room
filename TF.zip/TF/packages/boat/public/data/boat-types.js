export const boatTypes = [
    {
        img: '/images/boat-types/motor-boat.svg',
        name: 'Motor Boat',
    },
    {
        img: '/images/boat-types/sail-boat.svg',
        name: 'Sailboat',
    },
    {
        img: '/images/boat-types/rib-boat.svg',
        name: 'RIB',
    },
    {
        img: '/images/boat-types/house-boat.svg',
        name: 'House boat',
    },
    {
        img: '/images/boat-types/jet-ski-boat.svg',
        name: 'Jet ski',
    },
    {
        img: '/images/boat-types/yacht-boat.svg',
        name: 'Yacht',
    },
    {
        img: '/images/boat-types/catamaran-boat.svg',
        name: 'Catamaran',
    },
    {
        img: '/images/boat-types/gulet-boat.svg',
        name: 'Gulet',
    },
    {
        img: '/images/boat-types/motor-yacht-boat.svg',
        name: 'Motor Yacht',
    },
    
]