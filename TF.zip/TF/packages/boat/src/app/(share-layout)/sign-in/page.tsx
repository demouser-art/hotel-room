import SignIn from '@/components/auth/sign-in';
export default function page() {
  return <SignIn />;
}
