import SignUp from '@/components/auth/sign-up';
export default function page() {
  return <SignUp />;
}
