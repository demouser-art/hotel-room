import ComingSoon from '@/components/ui/coming-soon';

export default function Wishlist() {
  return (
    <>
      <ComingSoon />
    </>
  );
}
